from .metapruner import MetaPruner

class MagnitudePruner(MetaPruner):
    pass
    